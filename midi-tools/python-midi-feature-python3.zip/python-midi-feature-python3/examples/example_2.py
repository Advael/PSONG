import midi
pattern = midi.read_midifile("example.mid")
print(pattern)
